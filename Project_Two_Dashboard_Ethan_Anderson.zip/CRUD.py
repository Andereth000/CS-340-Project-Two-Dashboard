# Ethan Anderson
# 6-19-2024
# CS-340
from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        #USER = 'aacuser'
        #PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31605
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
# Ethan Anderson
# 6-19-2024
# CS-340
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        # If data exists, create in db and return true
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary
            return True
        # Else throw exception and return false
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return false

# Read method to implement the R in CRUD.
    def read(self, data_lookup):
        # If data exists, search database and return list
        if data_lookup is not None:
            data = list(self.database.animals.find(data_lookup))
            return data
        # Else throw exception and return empty list
        else:
            raise Exception("Read failed")
            return []
        
# Ethan Anderson
# 6-19-2024
# CS-340    
# Update method to implement the U in CRUD.
    def update(self, data_to_update, update_to):
        # If data exists, search database and update
        if data_to_update is not None and update_to is not None:
            data = self.database.animals.update_many(data_to_update, update_to)
            return data.modified_count # return num objects modified
        else:
            raise Exception("Update Failed")
        
        
# Delete method to implement the D in CRUD.
    def delete(self, data_delete):
        # If data exists, search database and delete
        if data_delete is not None:
            data = self.database.animals.delete_many(data_delete)
            return data.deleted_count # return num objects deleted
        else:
            raise Exception("Delete Failed")
        
            